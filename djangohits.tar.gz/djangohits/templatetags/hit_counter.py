from django import template
from djangohits.models import Visitor
from datetime import datetime
register = template.Library()

class HitCounterNode(template.Node):       
        
    def add_visitor(self,context):
        meta = context['request'].META
        visiting_url = meta['HTTP_HOST'] +meta['PATH_INFO']      
        
        last_visit = Visitor.objects.filter(ip=meta['REMOTE_ADDR'],url_visiting=visiting_url).order_by('-date_time')
        now = datetime.today() 

        if len(last_visit) != 0:
            diff = now - last_visit[0].date_time
            if diff.seconds < 30*60:
                return  str(Visitor.objects.filter(url_visiting=visiting_url).count())

        if 'HTTP_REFERER' in meta: 
            ref= meta['HTTP_REFERER'] 
        else: 
            ref = "direct"
        
        visitor = Visitor(ip = meta['REMOTE_ADDR'],
                                url_visiting = visiting_url,
                                referrer = ref,
                                date_time = now        
                                )
        visitor.save()
        
        
        return str(Visitor.objects.filter(url_visiting=visiting_url).count())
        
    def render(self,context):
        return self.add_visitor(context);
        


def hit_counter(parser,token):
    return HitCounterNode()
    
register.tag('hit_counter',hit_counter)

class SilentHitNode(HitCounterNode):
    def render(self,context):
        return "";
        
def silent_counter(parser,token):
    return SilentHitNode()
    
register.tag('silent_counter',silent_counter)
