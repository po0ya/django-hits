from django.contrib import admin

class VisitorAdmin(admin.ModelAdmin):
    list_display = ('ip', 'date_time', 'referrer','url_visiting')
    list_filter = ['date_time']
    search_fields = ['ip']
