from django.db import models

class Visitor(models.Model):
    ip = models.CharField(max_length = 16)
    url_visiting = models.CharField(max_length=255)
    referrer = models.CharField(blank=True,null=True,max_length=255)
    date_time = models.DateTimeField('date visited')
