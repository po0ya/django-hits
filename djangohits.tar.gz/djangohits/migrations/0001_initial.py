# encoding: utf-8
import datetime
from south.db import db
from south.v2 import SchemaMigration
from django.db import models

class Migration(SchemaMigration):
    
    def forwards(self, orm):
        
        # Adding model 'Visitor'
        db.create_table('djangohits_visitor', (
            ('referrer', self.gf('django.db.models.fields.URLField')(max_length=200, blank=True)),
            ('ip', self.gf('django.db.models.fields.CharField')(max_length=16)),
            ('date_time', self.gf('django.db.models.fields.DateTimeField')()),
            ('id', self.gf('django.db.models.fields.AutoField')(primary_key=True)),
            ('url_visiting', self.gf('django.db.models.fields.CharField')(max_length=255)),
        ))
        db.send_create_signal('djangohits', ['Visitor'])
    
    
    def backwards(self, orm):
        
        # Deleting model 'Visitor'
        db.delete_table('djangohits_visitor')
    
    
    models = {
        'djangohits.visitor': {
            'Meta': {'object_name': 'Visitor'},
            'date_time': ('django.db.models.fields.DateTimeField', [], {}),
            'id': ('django.db.models.fields.AutoField', [], {'primary_key': 'True'}),
            'ip': ('django.db.models.fields.CharField', [], {'max_length': '16'}),
            'referrer': ('django.db.models.fields.URLField', [], {'max_length': '200', 'blank': 'True'}),
            'url_visiting': ('django.db.models.fields.CharField', [], {'max_length': '255'})
        }
    }
    
    complete_apps = ['djangohits']
