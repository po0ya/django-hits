from djangohits.models import Visitor
from datetime import datetime

class CounterMiddleware:
    def process_request(self,request):
        if not (request.is_ajax()):
            visitor = Visitor(ip = request.META['REMOTE_ADDR'],
                                    url_visiting = request.META['HTTP_HOST'],
                                    referrer = request.META['HTTP_REFERER'],
                                    date_time = datetime.today()        
                                    )
            visitor.save()
        
